#ifndef COORDONNEES_H
#define COORDONNEES_H

#include <QObject>

class Coordonnees
{
private:
    double latitude;
    double longitude;

public:
    Coordonnees();

    double getLatitude() const;
    void setLatitude(double value);

    double getLongitude() const;
    void setLongitude(double value);

    void setCoordonnees(double x,double y);
};

#endif // COORDONNEES_H
