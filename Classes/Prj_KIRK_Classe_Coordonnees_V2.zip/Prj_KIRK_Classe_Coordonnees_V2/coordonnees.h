#ifndef COORDONNEES_H
#define COORDONNEES_H

#include <QObject>

struct coord
{
    double x;
    double y;
};

class Coordonnees
{
private:
    double latitude;
    double longitude;
    struct coord COORD;

public:
    Coordonnees();

    double getLatitude() const;
    void setLatitude(double value);

    double getLongitude() const;
    void setLongitude(double value);

    struct coord getCoordonnees() const;
    void setCoordonnees(double x,double y);
};

#endif // COORDONNEES_H
