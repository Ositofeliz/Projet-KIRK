#include "coordonnees.h"

double Coordonnees::getLatitude() const
{
    return latitude;
}

void Coordonnees::setLatitude(double value)
{
    latitude = value;
}

double Coordonnees::getLongitude() const
{
    return longitude;
}

void Coordonnees::setLongitude(double value)
{
    longitude = value;
}

coord Coordonnees::getCoordonnees() const
{
    return COORD;
}

void Coordonnees::setCoordonnees(double x, double y)
{

}

Coordonnees::Coordonnees()
{

}
